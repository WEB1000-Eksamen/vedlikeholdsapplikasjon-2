<?php

namespace Imgur\Exception;

interface ExceptionInterface {

}
