## Memegen
[Back to the navigation](index.md)

Link: [Imgur Memegen API](https://api.imgur.com/endpoints/memegen).

#### Default Memes

```php
<?php
$memes = $client->api('memegen')->defaultMemes();
```
